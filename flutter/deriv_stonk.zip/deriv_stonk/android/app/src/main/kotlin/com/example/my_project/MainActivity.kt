package com.mycompany.derivstonk

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
