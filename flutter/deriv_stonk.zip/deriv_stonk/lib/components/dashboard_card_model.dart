import '/flutter_flow/flutter_flow_util.dart';
import 'dashboard_card_widget.dart' show DashboardCardWidget;
import 'package:flutter/material.dart';

class DashboardCardModel extends FlutterFlowModel<DashboardCardWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
