import '/flutter_flow/flutter_flow_util.dart';
import 'custom_drawer_widget.dart' show CustomDrawerWidget;
import 'package:flutter/material.dart';

class CustomDrawerModel extends FlutterFlowModel<CustomDrawerWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
