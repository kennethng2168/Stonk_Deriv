
abstract class FFAppConstants {
  static const int tableRowValue = 1;
  static const int borderRadius = 10;
  static const int stockCardPadding = 15;
  static const int pieChartConstant = 100;
  static const List<int> bullBearList = [30, 70];
}
